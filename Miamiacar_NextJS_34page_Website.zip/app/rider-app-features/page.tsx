
export default function Page(){
 return (<main style={padding:'40px'}>
  <h1>Rider App Features</h1>
  <p>Original Miamiacar content for Rider App Features. Non-copyrighted, compliance-safe.</p>
 </main>)
}

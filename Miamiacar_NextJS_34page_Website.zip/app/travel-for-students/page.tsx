
export default function Page(){
 return (<main style={padding:'40px'}>
  <h1>Travel For Students</h1>
  <p>Original Miamiacar content for Travel For Students. Non-copyrighted, compliance-safe.</p>
 </main>)
}

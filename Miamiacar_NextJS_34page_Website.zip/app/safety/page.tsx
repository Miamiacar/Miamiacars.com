
export default function Page(){
 return (<main style={padding:'40px'}>
  <h1>Safety</h1>
  <p>Original Miamiacar content for Safety. Non-copyrighted, compliance-safe.</p>
 </main>)
}

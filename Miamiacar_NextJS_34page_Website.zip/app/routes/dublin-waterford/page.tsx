
export default function Page(){
 return (<main style={padding:'40px'}>
  <h1>Routes/Dublin Waterford</h1>
  <p>Original Miamiacar content for Routes/Dublin Waterford. Non-copyrighted, compliance-safe.</p>
 </main>)
}

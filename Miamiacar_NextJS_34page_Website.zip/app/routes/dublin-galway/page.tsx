
export default function Page(){
 return (<main style={padding:'40px'}>
  <h1>Routes/Dublin Galway</h1>
  <p>Original Miamiacar content for Routes/Dublin Galway. Non-copyrighted, compliance-safe.</p>
 </main>)
}


export default function Page(){
 return (<main style={padding:'40px'}>
  <h1>Routes/Dublin Cork</h1>
  <p>Original Miamiacar content for Routes/Dublin Cork. Non-copyrighted, compliance-safe.</p>
 </main>)
}

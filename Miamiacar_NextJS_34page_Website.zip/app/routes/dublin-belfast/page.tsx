
export default function Page(){
 return (<main style={padding:'40px'}>
  <h1>Routes/Dublin Belfast</h1>
  <p>Original Miamiacar content for Routes/Dublin Belfast. Non-copyrighted, compliance-safe.</p>
 </main>)
}


export default function Page(){
 return (<main style={padding:'40px'}>
  <h1>Live Trip Tracking</h1>
  <p>Original Miamiacar content for Live Trip Tracking. Non-copyrighted, compliance-safe.</p>
 </main>)
}

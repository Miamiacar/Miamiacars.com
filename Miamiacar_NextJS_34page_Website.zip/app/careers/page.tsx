
export default function Page(){
 return (<main style={padding:'40px'}>
  <h1>Careers</h1>
  <p>Original Miamiacar content for Careers. Non-copyrighted, compliance-safe.</p>
 </main>)
}


export default function Page(){
 return (<main style={padding:'40px'}>
  <h1>Help/Safety</h1>
  <p>Original Miamiacar content for Help/Safety. Non-copyrighted, compliance-safe.</p>
 </main>)
}


export default function Page(){
 return (<main style={padding:'40px'}>
  <h1>Help/Cancellations Refunds</h1>
  <p>Original Miamiacar content for Help/Cancellations Refunds. Non-copyrighted, compliance-safe.</p>
 </main>)
}

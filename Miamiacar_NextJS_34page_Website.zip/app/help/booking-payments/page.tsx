
export default function Page(){
 return (<main style={padding:'40px'}>
  <h1>Help/Booking Payments</h1>
  <p>Original Miamiacar content for Help/Booking Payments. Non-copyrighted, compliance-safe.</p>
 </main>)
}
